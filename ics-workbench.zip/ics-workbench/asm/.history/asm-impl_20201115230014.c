#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b) {
  asm ("add %1, %0;"
       : "+a" (a)
       : "b" (b)
      );
    return a;
}

int asm_popcnt(uint64_t x) {
  int s = 0;
  asm(
    "mov  $0,%[out]\n\t"
    "mov  $0,%%eax\n\t"
    "flag : \n\t"
    "cmp $0x40,%%eax\n\t"
    "jge  end\n\t"
    "mov %[in],%%rcx\n\t"
    "and  $1,%%rcx\n\t"
    "add  %%eax %[in]\n\t"
    "shr $1,%[out]\n\t"
    "add $1,%%eax\n\t"
    "jmp flag\n\t"
    "end:\n\t"
    :[out] "=k"(s)
    :[in ] "m"(x)
  );
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n) {
  return memcpy(dest, src, n);
}

int asm_setjmp(asm_jmp_buf env) {
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val) {
  longjmp(env, val);
}
