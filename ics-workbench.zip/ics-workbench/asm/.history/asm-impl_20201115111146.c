#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b) {
  asm ("add %1, %0;"
       : "+a" (a)
       : "b" (b)
      );
    return a;
}

int asm_popcnt(uint64_t x) {
  int s = 0;
  asm(
    "xor %%rax, %%rax\n"
    "movl $0x0, -0x4(%%rbp)\n"
    "dest2:mov %[in], -0x18(%%rbp)\n"
    "and $0x1, %[in]\n"
    "test %[in], %[in]\n"
    "je dest1\n"
    "inc %%rax\n"
    "dest1:mov -0x18(%%rbp),%[in]\n"
    "shr $0x1, %[in] \n"
    "incl -0x4(%%rbp)\n"
    "cmp $0x3f,-0x4(%%rbp)\n"
    "jle dest2\n"
    "mov %%rax, -0x18(%%rbp)\n"
    "mov -0x18(%%rbp), %[out]\n"
    : [out] "+g"(s)
    : [in] "r" (x)
    : "%rax","cc","memory");
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n) {
  return memcpy(dest, src, n);
}

int asm_setjmp(asm_jmp_buf env) {
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val) {
  longjmp(env, val);
}
