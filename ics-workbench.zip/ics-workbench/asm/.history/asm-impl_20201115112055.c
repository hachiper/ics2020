#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b) {
  asm ("add %1, %0;"
       : "+a" (a)
       : "b" (b)
      );
    return a;
}

int asm_popcnt(uint64_t x) {
  int s = 0;
  asm("mov %1, -0x18(%%rbp)\n"
      "movl $0x0, -0x8(%%rbp)\n" // i
      "jmp dest1\n"
      "dest3: mov -0x8(%%rbp), %%eax\n"
      "mov -0x18(%%rbp), %%rdx\n"
      "mov %%eax, %%ecx\n"
      "shr %%cl, %%rdx\n"
      "mov %%rdx, %%rax\n"
      "and $0x1, %%eax\n"//???
      "test %%rax,%%rax\n"
      "je dest2\n"
      "addl $0x1, %0\n"
      "dest2: addl $0x1, -0x8(%%rbp)\n"// i++
      "dest1: cmpl $0x3f, -0x8(%%rbp)\n"
      "jle dest3\n"
      : "+r"(s) //占位符 %0
      : "r"(x) //占位符 %1
      :"%rax", "%eax", "%ecx","%rdx","%cl");
      
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n) {
  return memcpy(dest, src, n);
}

int asm_setjmp(asm_jmp_buf env) {
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val) {
  longjmp(env, val);
}
