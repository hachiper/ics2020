#include "common.h"
#include <inttypes.h>
#include <time.h>

void mem_read(uintptr_t block_num, uint8_t *buf);
void mem_write(uintptr_t block_num, const uint8_t *buf);

static uint64_t cycle_cnt = 0;
typedef struct {
  bool dirty;
  bool valid;
  uint32_t tag;
  uint8_t data[64];
}cache_block;
//cash 16kb=4*64*64
cache_block cache[64][4];



void cycle_increase(int n) { cycle_cnt += n; }

// TODO: implement the following functions

uint32_t cache_read(uintptr_t addr) {

  return 0;
}

void cache_write(uintptr_t addr, uint32_t data, uint32_t wmask) {

}

void init_cache(int total_size_width, int associativity_width) {
  int a=total_size_width<<1;
  int b=associativity_width<<1;
  for (int i=0;i<a;i++){
    for (int j=0;j<b;j++){
      cache[i][j].valid=false;
      cache[i][j].dirty=false;
    }
  }
  return 0;
}


void display_statistic(void) {

}
