#include "common.h"
#include <inttypes.h>
#include <string.h>
// #include <time.h>

typedef struct
{
  bool dirty;
  bool valid;
  uint32_t tag;
  uint8_t data[64];
} cache_block;
//cash 16kb=4*64*64
cache_block cache[64][4];

void mem_read(uintptr_t block_num, uint8_t *buf);
void mem_write(uintptr_t block_num, const uint8_t *buf);

void write_it(uintptr_t group_id, int i, uintptr_t block_address, uint32_t data, uint32_t wmask)
{
  uint32_t *data2 = (void *)(cache[group_id][i].data) + (block_address & ~0x3);
  *data2 = (*data2 & ~wmask) | (data & wmask);
}

static uint64_t cycle_cnt = 0;

void cycle_increase(int n) { cycle_cnt += n; }

// TODO: implement the following functions

uint32_t cache_read(uintptr_t addr)
{
  uintptr_t ad_tag = addr & 63,
            group_id = (addr >> 6) & 63,
            block_address = (addr >> 12);
  bool hit = false;
  uint32_t *ret;
  for (int i = 0; i < 4; i++)
  {
    if (cache[group_id][i].tag == ad_tag && cache[group_id][i].valid == true)
    {
      hit = true;
      ret = (void *)(cache[group_id][i].data) + (block_address & ~0x3);
      break;
    }
  }

  if (!hit)
  {
    bool empty2 = false;
    for (int i = 0; i < 4; i++)
    {
      if (cache[group_id][i].valid == false)
      {
        empty2 = true;
        mem_read(addr >> 6, cache[group_id][i].data);
        ret = (void *)(cache[group_id][i].data) + (block_address & ~0x3);
        cache[group_id][i].tag = ad_tag;
        cache[group_id][i].valid = true;
        cache[group_id][i].dirty = false;
        break;
      }
    }

    if (!empty2)
    {
      int sra = rand() % 4;
      if (cache[group_id][sra].dirty )
      {
        mem_write((cache[group_id][sra].tag << 6) | group_id, cache[group_id][sra].data);
      }
      
      mem_read(addr >> 6, cache[group_id][sra].data);
      ret = (void *)(cache[group_id][sra].data) + (block_address & ~0x3);
      cache[group_id][sra].tag = ad_tag;
      cache[group_id][sra].valid = true;
      cache[group_id][sra].dirty = false;
    }
    
  }

  return *ret;
}

void cache_write(uintptr_t addr, uint32_t data, uint32_t wmask) {
  // clock_gettime(CLOCK_REALTIME, &time_now[0]); 
  // tot_increase(1);
  uintptr_t block_addr=(addr&63),//取低6位
            grp_id=((addr>>6)&63),//取中间6位
            tag=(addr>>12);
  bool is_hit=false;
  for (int i=0;i<4;++i)
    if (cache[grp_id][i].tag==tag&&cache[grp_id][i].valid==true)
    {
      is_hit=true;
      write_it(grp_id,i,block_addr,data,wmask);
      cache[grp_id][i].dirty=true;//写入cache但还没写入内存
      // clock_gettime(CLOCK_REALTIME, &time_now[1]);
      // cache_wrtime+=(time_now[1].tv_sec-time_now[0].tv_sec)*1000000000+(time_now[1].tv_nsec-time_now[0].tv_nsec);
      break;
    }
  if (is_hit==false)
  {
    //寻找空行
    bool is_empty=false;
    for (int i=0;i<4;++i)
      if (cache[grp_id][i].valid==false)
      {
        is_empty=true;hit_increase(1);
        //mem_uncache_write(addr,data,wmask);//先在内存中修改
        mem_read(addr>>6,cache[grp_id][i].data);//再从内存读入cache
        write_it(grp_id,i,block_addr,data,wmask);//将data写入cache
        cache[grp_id][i].tag=tag;
        cache[grp_id][i].valid=true;
        cache[grp_id][i].dirty=false;
        mem_write(addr>>6,cache[grp_id][i].data);//在cache中修改完成之后写回内存
        break;
      }
    if (is_empty==false)
    {
      //随机替换
      int repl=rand()%4;
      if (cache[grp_id][repl].dirty==true)//需要写回
        mem_write((cache[grp_id][repl].tag<<6)|grp_id,cache[grp_id][repl].data);
      //mem_uncache_write(addr,data,wmask);
      mem_read(addr>>6,cache[grp_id][repl].data);
      write_it(grp_id,repl,block_addr,data,wmask);
      cache[grp_id][repl].tag=tag;
      cache[grp_id][repl].valid=true;
      cache[grp_id][repl].dirty=false;
      mem_write(addr>>6,cache[grp_id][repl].data);
    }
  }
  
}
void init_cache(int total_size_width, int associativity_width)
{
  int group_num = (1 << associativity_width);
  int uintsize = (1 << total_size_width) / group_num / BLOCK_SIZE;
  for (int i = 0; i < uintsize; i++)
  {
    for (int j = 0; j < group_num; j++)
    {
      cache[i][j].valid = false;
      cache[i][j].dirty = false;
      // memset(cache[i][j].data, 0, sizeof(cache[i][j].data));
      // cache[i][j].tag = 0;
    }
  }
}

void display_statistic(void)
{
}
