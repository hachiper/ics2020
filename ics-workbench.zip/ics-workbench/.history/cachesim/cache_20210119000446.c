#include "common.h"
#include <inttypes.h>

void mem_read(uintptr_t block_num, uint8_t *buf);
void mem_write(uintptr_t block_num, const uint8_t *buf);

typedef struct {
  bool valid;
  bool dirty;
  uint8_t data[64];
  uint32_t tag;
  
}cache_block;
cache_block Cache[64][4];

static uint64_t cycle_cnt = 0;

void cycle_increase(int n) { cycle_cnt += n; }
// TODO: implement the following functions
void write_it(uintptr_t grp_id,int i,uintptr_t block_addr,uint32_t data,uint32_t wmask)
{
  uint32_t *p = (void *)(Cache[grp_id][i].data) + (block_addr & ~0x3);
  *p = (*p & ~wmask) | (data & wmask);
}

uint32_t cache_read(uintptr_t addr) {
  uintptr_t block_addr=(addr&63),
            grp_id=((addr>>6)&63),
            tag=(addr>>12);
  bool is_hit=false;
  uint32_t *ret;
  for (int i=0;i<4;++i)
  if (Cache[grp_id][i].tag==tag&&Cache[grp_id][i].valid==true)
  {
    is_hit=true;
    ret = (void *)(Cache[grp_id][i].data) + (block_addr & ~0x3);
    break;
    
  }
  if (is_hit==false)
  { 
    bool has_empty=false;
    for (int i=0;i<4;++i)
      if (!Cache[grp_id][i].valid)
      {
        has_empty=true;
        mem_read(addr>>6,Cache[grp_id][i].data);
        ret = (void *)(Cache[grp_id][i].data) + (block_addr & ~0x3);
        Cache[grp_id][i].tag=tag;
        Cache[grp_id][i].valid=true;
        Cache[grp_id][i].dirty=false;
        break;
      }
    if (!has_empty)
    {
      int repl=rand()%4;
      if (Cache[grp_id][repl].dirty)
        mem_write((Cache[grp_id][repl].tag<<6)|grp_id,Cache[grp_id][repl].data);
      mem_read(addr>>6,Cache[grp_id][repl].data);
      ret = (void *)(Cache[grp_id][repl].data) + (block_addr & ~0x3);
      Cache[grp_id][repl].tag=tag;
      Cache[grp_id][repl].valid=true;
      Cache[grp_id][repl].dirty=false;
    }
  }
  return *ret;
}

void cache_write(uintptr_t addr, uint32_t data, uint32_t wmask) {
  uintptr_t block_addr=(addr&63),//取低6位
            grp_id=((addr>>6)&63),//取中间6位
            tag=(addr>>12);
  bool is_hit=false;
  for (int i=0;i<4;++i)
    if (Cache[grp_id][i].tag==tag&&Cache[grp_id][i].valid==true)
    {
      is_hit=true;
      write_it(grp_id,i,block_addr,data,wmask);
      Cache[grp_id][i].dirty=true;//写入cache但还没写入内存
      // clock_gettime(CLOCK_REALTIME, &time_now[1]);
      // cache_wrtime+=(time_now[1].tv_sec-time_now[0].tv_sec)*1000000000+(time_now[1].tv_nsec-time_now[0].tv_nsec);
      break;
    }
  if (is_hit==false)
  {
    bool is_empty=false;
    for (int i=0;i<4;++i)
      if (!Cache[grp_id][i].valid)
      {
        is_empty=true;
        //mem_uncache_write(addr,data,wmask);//先在内存中修改
        mem_read(addr>>6,Cache[grp_id][i].data);//再从内存读入cache
        write_it(grp_id,i,block_addr,data,wmask);//将data写入cache
        Cache[grp_id][i].tag=tag;
        Cache[grp_id][i].valid=true;
        Cache[grp_id][i].dirty=false;
        mem_write(addr>>6,Cache[grp_id][i].data);//在cache中修改完成之后写回内存
        break;
      }
    if (!is_empty)
    {
      int repl=rand()%4;
      if (Cache[grp_id][repl].dirty)
        mem_write((Cache[grp_id][repl].tag<<6)|grp_id,Cache[grp_id][repl].data);
      mem_read(addr>>6,Cache[grp_id][repl].data);
      write_it(grp_id,repl,block_addr,data,wmask);
      Cache[grp_id][repl].tag=tag;
      Cache[grp_id][repl].valid=true;
      Cache[grp_id][repl].dirty=false;
      mem_write(addr>>6,Cache[grp_id][repl].data);
    }
  }
  
}
void init_cache(int total_size_width, int associativity_width)
{
  int group_num = (1 << associativity_width);
  int uintsize = (1 << total_size_width) / group_num / BLOCK_SIZE;
  for (int i = 0; i < uintsize; i++)
  {
    for (int j = 0; j < group_num; j++)
    {
      Cache[i][j].valid = false;
      Cache[i][j].dirty = false;
    }
  }
}

void display_statistic(void)
{

}
