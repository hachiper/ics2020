#include "common.h"
#include <inttypes.h>
// #include <time.h>

void mem_read(uintptr_t block_num, uint8_t *buf);
void mem_write(uintptr_t block_num, const uint8_t *buf);

static uint64_t cycle_cnt = 0;
typedef struct {
  bool dirty;
  bool valid;
  uint32_t tag;
  uint8_t data[64];
}cache_block;
//cash 16kb=4*64*64
cache_block cache[64][4];



void cycle_increase(int n) { cycle_cnt += n; }

// TODO: implement the following functions

uint32_t cache_read(uintptr_t addr) {

  return 0;
}

void cache_write(uintptr_t addr, uint32_t data, uint32_t wmask) {
  uintptr_t ad_tag=addr&63,
            group_id=(addr>>6)&63,
            block_address=(addr>>12);
  bool hit=false;
  for (int i=0;i<4;i++){
    if (ad_tag==cache[group_id][i].tag&&cache[group_id][i].valid==true){
      hit=true;
      memset(cache[group_id][i].data,data,sizeof(data));
      cache[group_id][i].dirty=true;
      break;
    }
  }
  if (!hit){
    int num=rand()%4;
    if (cache[group_id][num].dirty){
      mem_write((cache[group_id][num].tag<<6)|(group_id),cache[group_id][num].data);
      cache[group_id][num].dirty=false;
    }

  }

}

void init_cache(int total_size_width, int associativity_width) {
  int group_num=(1<<associativity_width);
  int uintsize=(1<<total_size_width)/group_num/BLOCK_SIZE;
  for (int i=0;i<uintsize;i++){
    for (int j=0;j<group_num;j++){
      cache[i][j].valid=false;
      cache[i][j].dirty=false;
      memset(cache[i][j].data,0,sizeof(cache[i][j].data));
      cache[i][j].tag=0;
    }
  }
}


void display_statistic(void) {

}
