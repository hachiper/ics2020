#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
  uint64_t lista[32],alist[32],listb[32],blist[32];
  uint64_t combine[64];
  int bytes=sizeof(int);
  for (int i=0;i<32;i++){
    alist[i]=lista[i]=blist[i]=listb[i]=0;
  }
  for (int i=0;i<64;i++){
    combine[i]=0;
  }
  unsigned mask=1u<<(bytes*8-1);
  uint64_t count=0;
  for (;mask;mask>>=1){
    int ak=a& mask ? 1:0;
    lista[count]=ak;
    count++;
  }
  mask=1u<<(bytes*8-1);
  count=0;
  for (;mask;mask>>=1){
    uint64_t bk=b& mask ? 1:0;
    listb[count]=bk;
    count++;
  }
  for (uint64_t y=0;y<32;y++)
  {
    alist[31-y]=lista[y];
    blist[31-y]=listb[y];
  }

  for(uint64_t i=0;i<32;i++){
    for(uint64_t j=0;j<32;j++){
      combine[i+j]+=alist[i]&blist[j];
      //if(alist[i]&blist[j]!=0) printf("%u %u %u \n",i,j,i+j);
      }
    }
    //printf("wwww\n");
  //for (uint64_t i=0;i<128;i++){
  //  if (combine[i]!=0) printf("%u %u \n",i,combine[i]);
  //}
  int result=0;
  for (int i=0;i<64;i++){
    result+=combine[i]<<=i;
  }
  while (result>0){
    result=result-m;
  }  
  return result+=m;
}


