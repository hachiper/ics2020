#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
  uint64_t lista[64],alist[64],listb[64],blist[64];
  uint64_t combine[128];
  int bytes=sizeof(int);
  for (int i=0;i<64;i++){
    lista[i]=alist[i]=listb[i]=blist[i]=0;
  }
  for (int i=0;i<128;i++){
    combine[i]=0;
  }
  unsigned mask1=1u<<(bytes*8-1);
  unsigned mask2=1u<<(bytes*8-1);
  int count1=0;
  int count2=0;
  for(;mask1;mask1>>1){
    int pa=a&mask1?1:0;
    lista[count1]=pa;
    count1++;
  }
  for (;mask2;mask2>>1){
    int pa=b&mask2?1:0;
    listb[count2]=pa;
    count2++;
  }
  for (int y=0;y<64;y++)
  {
    alist[63-y]=lista[y];
    blist[63-y]=listb[y];
  }
  for(int i=0;i<64;i++){
    for(int j=0;j<64;j++){
      combine[i+j]+=alist[i]&blist[j];
    }
  }
  uint64_t pow=1;
  uint64_t result=0;
  for (int i=0;i<128;i++){
    result+=combine[i]*pow;
    pow=pow*2;
  }
  while (result>0){
    result=result-m;
  }  
  return result+=m;
}


