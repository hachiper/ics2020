#include <stdint.h>
#include <stdio.h>
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
    uint64_t A[64],B[64],sum[128];
	int i=0,j=0;
    for (int y=0;y<128;y++){
        sum[y]=0;
    }
	for(;a>=1;i++){
		A[i]=a&1;
		a>>=1;
	}
	for(;b>=1;j++){
		B[j]=b&1;
		b>>=1;
	}
    
	for (int aji=0;aji<i;aji++){
		for (int bji=0;bji<j;bji++){
			sum[aji+bji]+=A[aji]&B[bji];
		}
	}
  	uint64_t mod=0,sum1=0;
	for(int len2=i+j-1;len2>=0;len2--){
		if(mod<<1 < mod){
		mod<<=1;
		sum1=sum[len2]+mod-m;
		}
		else{
		mod<<=1;
		sum1=sum[len2]+mod;}
		while(sum1>=m){
			sum1=sum1-m;
		}
		mod=sum1;
}	
	return  mod;
}
