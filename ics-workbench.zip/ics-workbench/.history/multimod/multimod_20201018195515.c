#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
  uint64_t alist[64],blist[64],sum[128];
  int ai=0,bi=0;
  for(;a>=1;ai++){
    alist[ai]=a&1;
    a>>=1;
  }
  ai--;
  for(;b>=1;bi++){
    blist[bi]=b&1;
    b>>=1;
  }
  bi--;
  int len_sum=0;
  int ka=0;
  for (;len_sum<=ai+bi+1;len_sum++){
    int a_l=0,b_l=0,buf=0;
    for (;a_l<=ai;a_l++){
      b_l=len_sum-a_l;
      if(b_l<0) break;
      else if (b_l>=0&&b_l<=bi) buf=buf+(alist[a_l]&blist[b_l]);
    }
    sum[len_sum]=(buf+ka)&1;
    ka=(ka+buf)>>1;
  }
  len_sum=len_sum-1;
  uint64_t consu=0,oe=0;
  for(;len_sum>=0;len_sum){
    if((consu<<1)<consu){
      oe=sum[len_sum]+consu-m;
      
    }
    else {
      consu<<1;
      oe=sum[len_sum]+consu;}
      while (oe>=m){
        oe-=m;
      }
      consu=oe;
  }
  return consu;
}


