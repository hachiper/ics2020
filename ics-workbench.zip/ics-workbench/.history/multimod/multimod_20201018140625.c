#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
  uint64_t lista[1000],alist[1000],listb[1000],blist[1000];
  uint64_t al=a;
  uint64_t bl=b;
  int ac=0;
  int bc=0;
  while (al>0){
    lista[ac]=al%2;
    ac++;
    al=al/2;
  }
  lista[ac]=al;
  for (int i=ac;i>=0;i--){
    alist[ac-i]=lista[i];
  }
  while (bl>0){
    listb[bc]=bl%2;
    bc++;
    bl=bl/2;
  }
  listb[bc]=bl;
  for (int i=bc;i>=0;i--){
    blist[bc-i]=listb[i];
  } 
  uint64_t combine[10000];
  for(int i=0;i<=ac;i++){
    for(int j=0;j<=bc;j++){
      combine[i+j]=alist[i]&blist[j];
    }
  }
  uint64_t pow=1;
  uint64_t result=0;
  for (int i=0;i<=ac+bc;i++){
    result+=combine[i]*pow;
    pow=pow*2;
  }
  while (result>0){
    result=result-m;
  }  
  return result+=m;
}


