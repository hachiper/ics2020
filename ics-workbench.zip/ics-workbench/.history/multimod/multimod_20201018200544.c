#include <stdint.h>
#include <stdio.h>
#include <inttypes.h>
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
  uint64_t alist[64],blist[64],sum[128];
  int ai=0,bi=0;
  for(;a>=1;ai++){
    alist[ai]=a&1;
    a>>=1;
  }
  if(ai>=1) ai--;
  for(;b>=1;bi++){
    blist[bi]=b&1;
    b>>=1;
  }
  bi--;
  int p=0;
  int c=0;
  for (;p<=ai+bi+1;p++)
  {
    int k=0,n=0,s=0;
    for (;k<=ai;k++){
      n=p-k;
      if(n<0) break;
      else if (n>=0&&n<=j) s=(alist[k]&blist[n])+s;
    }
    sum[p]=(s+c)&1;
    c=(c+s)>>1;
  }
  p--;
  int yushu=0,he=0;
  for (;p>=0;p--){
    if(yushu<<1<yushu){
      yushu<=1;
      he=sum[p]+yushu-m;
    }
    else {
      yushu<<=1;
      he=sum[p]+yushu;
    }
    while(he>=m){
      he=he-m;
    }
    yushu=he;
  }
return yushu;
}


