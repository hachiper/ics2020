#include <stdint.h>
int add(uint64_t a, uint64_t b){
    int sum = a;
    int carry = b;
    while(carry){
        int tmps = sum;
        sum = tmps ^ carry;
        carry = (tmps & carry) << 1;
    }
    return sum;
}

int multiply(uint64_t a, uint64_t b)
{ 
  uint64_t multiplier=a ;
  uint64_t multiplicand=b;

  int product = 0;
  int count = 0;

  while(count < multiplier)
    {
    product = add(product, multiplicand);
    count = add(count, 1);
    }

    return product;
}
uint64_t multimod(uint64_t a, uint64_t b, uint64_t m) {
  
  uint64_t result=multiply(a,b);
  while (result>0){
    result=result-m;
  }  
  return result+=m;
}
