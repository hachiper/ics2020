#include <string.h>
#include <stdio.h>
void *memcpy_test(void *dest,const void *src,size_t n){
    if (!(dest&&src ))return 0;
    void *out0=dest;
    while (n){
        *(char *)dest =*(char *)src;
        dest++;
        src++;
        n--;
    }
    return out0;
}
// int main(){
//     return 0;
// }