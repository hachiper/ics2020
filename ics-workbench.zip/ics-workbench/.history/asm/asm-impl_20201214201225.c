#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s = 0;
  asm(
      "mov  $0,%[out]\n\t"
      "mov  $0,%%edx\n\t"
      "flag:      \n\t"
      "cmp $0x40,%%edx\n\t"
      "jge  end \n\t"
      "mov %[in],%%rcx\n\t"
      "and  $1,%%rcx \n\t"
      "add  %%ecx,%[out]\n\t"
      "shr $1,%[in]\n\t"
      "add $1,%%edx\n\t"
      "jmp flag;"
      "end: \n\t"
      : [ out ] "=a"(s)
      : [ in ] "b"(x));
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{
  asm(
    "test %%rdi,%%rdi\n\t"
    "je memcpy_test+47\n\t"
    "test %%rsi,%%rsi\n\t"
    "je memcpy_test+47\n\t"
    "xor %%ecx,%%ecx\n\t"
    "test %%rdx,%%rdx\n\t"
    "je memcpy_test+38\n\t"
    "movzbl (%%rsi,%%rcx,1),%%r8d\n\t"
    "mov %%r8b,(%%rdi,%%rcx,1)\n\t"
    "addq $0x1,%%rcx\n\t"
    "cmp %%rcx,%%rdx\n\t"
    "jne memcpy_test+24\n\t"
    "movq %%rdi,%%rax\n\t"
    "movq %%rax,%0\n\t"
    "retq\n\t"   
    "xchg %%ax,%%ax\n\t"
    "xor %%eax,%%eax\n\t"
    "movq %%rax,%0\n\t"
    "retq\n\t"   
    :"=g"(dest)
    :
    :"rdi","rsi","ecx","rax"
  );
  return dest;

}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
