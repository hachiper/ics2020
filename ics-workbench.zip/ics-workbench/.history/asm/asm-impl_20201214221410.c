#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s;
  asm (
        "movl $0,%%eax;"
        "movl $0,%%edi;"
        "st:cmpl $0x40,%%edi;"
        "jge end;"//i>63 结束
        "movq %%rbx,%%rcx;"
        "and $1,%%rcx;"
        "add %%ecx,%%eax;"
        "shr $1,%%rbx;"
        "add $1,%%edi;"
        "jmp st;"
        "end:"
        :"=a"(s)
        :"b"(x)
        :"%edi","%rcx","cc"
      );
  return s
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{
  asm volatile (
    "mov $0,%%rdi;"//%edi=i
    "flag1:cmp %%rdx,%%rdi;"
    "jge end1;"//i>=n 结束
    "movzbl (%%rcx),%%rax;"
    "mov %%rax,(%%rbx);"
    "add $1,%%rbx;"
    "add $1,%%rcx;"
    "add $1,%%rdi;"
    "jmp flag1;"
    "end1:"
    :
    :"b"(dest),"c"(src),"d"(n)
    :"%rdi","%rax","memory","cc"
  );
  return dest;

}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
