#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s = 0;
  asm(
      "mov  $0,%[out]\n\t"
      "mov  $0,%%edx\n\t"
      "flag:      \n\t"
      "cmp $0x40,%%edx\n\t"
      "jge  end \n\t"
      "mov %[in],%%rcx\n\t"
      "and  $1,%%rcx \n\t"
      "add  %%ecx,%[out]\n\t"
      "shr $1,%[in]\n\t"
      "add $1,%%edx\n\t"
      "jmp flag;"
      "end: \n\t"
      : [ out ] "=a"(s)
      : [ in ] "b"(x));
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{
  int dwsize=n/4;
  int bytesize=n%4;
  _asm_{
    mov edi,dest
    mov esi,src
    mov ecx,dwsize
    rep movs dword ptr es:[edi],dword ptr ds:[esi]
    mov ecx,bytesize
    rep movs byte ptr es:[edi],byte ptr ds:[esi]
  }
  return dest;

}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
