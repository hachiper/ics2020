#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s = 0;
  asm(
      "mov  $0,%%eax\n\t"
      "mov  $0,%%edx\n\t"
      "flag: cmp $0x40,%%edx\n\t"
      "jge  end \n\t"
      "mov  %%ebx,(%%rcx)\n\t"
      "and  $1,%%rcx \n\t"
      "add  %%ecx,%%eax\n\t"
      "shr $1,%%ebx\n\t"
      "add $1,%%edx\n\t"
      "jmp flag;"
      "end: "
      : "=a"(s)
      :  "b"(x));
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{
  asm volatile (
    "mov $0,%%rdi;"//%edi=i
    "flag1:cmp %%rdx,%%rdi;"
    "jge end1;"//i>=n 结束
    "movzbl (%%rcx),%%rax;"
    "mov %%rax,(%%rbx);"
    "add $1,%%rbx;"
    "add $1,%%rcx;"
    "add $1,%%rdi;"
    "jmp flag1;"
    "end1:"
    :
    :"b"(dest),"c"(src),"d"(n)
    :"%rdi","%rax","memory","cc"
  );
  return dest;

}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
