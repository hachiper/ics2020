#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s;
  asm (
        "mov $0,%%eax;"
        "mov $0,%%edi;"
        "st:cmp $0x40,%%edi;"
        "jge end;"
        "mov %%rbx,%%rcx;"
        "and $1,%%rcx;"
        "add %%ecx,%%eax;"
        "shr $1,%%rbx;"
        "add $1,%%edi;"
        "jmp st;"
        "end:"
        :"=a"(s)
        :"b"(x)
        :"%edi","%rcx","cc"
      );
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{
  asm volatile (
    "mov $0,%%rdi;"
    "flag1:cmp %%rdx,%%rdi;"
    "jge end1;"
    "movzbl (%%rcx),%%rax;"
    "mov %%rax,(%%rbx);"
    "add $1,%%rbx;"
    "add $1,%%rcx;"
    "add $1,%%rdi;"
    "jmp flag1;"
    "end1:"
    :
    :"b"(dest),"c"(src),"d"(n)
    :"%rdi","%rax","memory","cc"
  );
  return dest;

}

int asm_setjmp(asm_jmp_buf env) {
  asm ("mov %[env], %%rdx\n"
       "mov %%rbx, (%%rdx)\n" // * 保存rbx
       "mov (%%rsp), %%rax\n"
       "mov %%rax, 0x8(%%rdx)\n" // * rsp存放rbp的旧址
       "mov %%r12, 0x10(%%rdx)\n"
       "mov %%r13, 0x18(%%rdx)\n"
       "mov %%r14, 0x20(%%rdx)\n"
       "mov %%r15, 0x28(%%rdx)\n"
       "lea 0x10(%%rsp), %%rax\n"
       "mov %%rax, 0x30(%%rdx)\n" // * rsp+10的地址是rsp的旧值
       "mov 0x8(%%rsp), %%rax\n"
       "mov %%rax, 0x38(%%rdx)\n"  // * rsp+8存放pc
       : 
       : [env] "m"(env)
       : "%rax", "cc", "memory");
  return 0;
}

void asm_longjmp(asm_jmp_buf env, int val) {
  asm ("mov %[env], %%rdx\n"
       "mov (%%rdx), %%rbx\n"
       "mov 0x10(%%rdx), %%r12\n"
       "mov 0x18(%%rdx), %%r13\n"
       "mov 0x20(%%rdx), %%r14\n"
       "mov 0x28(%%rdx), %%r15\n"
       "mov %[val], %%rax\n"
       "mov 0x30(%%rdx), %%rsp\n"
       "mov 0x8(%%rdx), %%rbp\n" // * gdb好像是检测ebp的改动来判断在哪个函数里面
       "mov 0x38(%%rdx), %%rdx\n"
       "jmpq *%%rdx\n"
       : 
       : [env] "m"(env), [val] "m"(val)
       : "cc", "memory");
}