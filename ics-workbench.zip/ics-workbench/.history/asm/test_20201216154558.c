#include <stdio.h>
#include <setjmp.h>
jmp_buf buf;
int main(){
    int r = setjmp(buf);
    if (r == 0) {
    longjmp(buf, 123);
  } else {
    //assert(r == 123);
    printf("PASSED.\n");
  }

}