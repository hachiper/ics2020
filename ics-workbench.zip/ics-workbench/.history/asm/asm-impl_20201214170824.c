#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s = 0;
  asm(
      "mov  $0,%[out]\n\t"
      "mov  $0,%%edx\n\t"
      "flag:      \n\t"
      "cmp $0x40,%%edx\n\t"
      "jge  end \n\t"
      "mov %[in],%%rcx\n\t"
      "and  $1,%%rcx \n\t"
      "add  %%ecx,%[out]\n\t"
      "shr $1,%[in]\n\t"
      "add $1,%%edx\n\t"
      "jmp flag;"
      "end: \n\t"
      : [ out ] "=a"(s)
      : [ in ] "b"(x));
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{
  
  int d0, d1, d2;
  asm volatile(
      "rep ; movsl\n\t"
      "movl $4,%%ecx\n\t"
      "rep ; movsb\n\t"
      : "=&c"(d0), "=&D"(d1), "=&S"(d2)
      : "0"(n >> 2), "g"(n & 3), "1"(dest), "2"(src)
      : "memory");

  return dest;
}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
