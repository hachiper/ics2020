#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s = 0;
  asm(
      "mov  $0,%[out]\n\t"
      "mov  $0,%%edx\n\t"
      "flag:      \n\t"
      "cmp $0x40,%%edx\n\t"
      "jge  end \n\t"
      "mov %[in],%%rcx\n\t"
      "and  $1,%%rcx \n\t"
      "add  %%ecx,%[out]\n\t"
      "shr $1,%[in]\n\t"
      "add $1,%%edx\n\t"
      "jmp flag;"
      "end: \n\t"
      : [ out ] "=a"(s)
      : [ in ] "b"(x));
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{

  void *pos = NULL;
  asm volatile(
      "mov %[dest],%%rax\n\t"
      "mov %%rax,-0x18(%%rbp)\n\t"
      "mov %[src],%%rax\n\t"
      "mov %%rax,-0x20(%%rbp)\n\t"
      "mov %[n],%%rax\n\t"
      "mov %%rax,-0x28(%%rbp)\n\t"
      "mov -0x18(%%rbp),%%rax\n\t"
      "movl $0x0,-0xc(%%rbp)\n\t"
      "jmp start\n\t"
      "loop: mov -0x20(%%rbp),%%rax\n\t"
      "movzbl (%%rax),%%edx\n\t"
      "mov -0x18(%%rbp),%%rax\n\t"
      "mov %%dl,(%%rax)\n\t"
      "addq $0x1,-0x18(%%rbp)\n\t"
      "addq $0x1,-0x20(%%rbp)\n\t"
      "addq $0x1,-0xc(%%rbp),%%rax\n\t"
      "cltq\n\t"
      "cmp %%rax,-0x28(%%rbp)\n\t"
      "ja loop\n\t"
      : [ pos ] "+g"(pos)
      : [ dest ] "m"(dest), [ src ] "m"(src), [ n ] "m"(n)
      : "%rax","%edx","cc","memory" );

  return dest;
}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
