#include "asm.h"
#include <string.h>

int64_t asm_add(int64_t a, int64_t b)
{
  asm("add %1, %0;"
      : "+a"(a)
      : "b"(b));
  return a;
}

int asm_popcnt(uint64_t x)
{
  int s = 0;
  asm(
      "mov  $0,%[out]\n\t"
      "mov  $0,%%edx\n\t"
      "flag:      \n\t"
      "cmp $0x40,%%edx\n\t"
      "jge  end \n\t"
      "mov %[in],%%rcx\n\t"
      "and  $1,%%rcx \n\t"
      "add  %%ecx,%[out]\n\t"
      "shr $1,%[in]\n\t"
      "add $1,%%edx\n\t"
      "jmp flag;"
      "end: \n\t"
      : [ out ] "=a"(s)
      : [ in ] "b"(x));
  return s;
}

void *asm_memcpy(void *dest, const void *src, size_t n)
{

  void *pos = NULL;
  asm volatile(
      "mov %[dest],%%eax\n\t"
      "mov %%eax,-0x18(%%ebp)\n\t"
      "mov %[src],%%eax\n\t"
      "mov %%eax,-0x20(%%ebp)\n\t"
      "mov %[n],%%eax\n\t"
      "mov %%eax,-0x28(%%ebp)\n\t"
      "mov -0x18(%%rbp),%%eax\n\t"
      "movl $0x0,-0xc(%%ebp)\n\t"
      "jmp start\n\t"
      "loop: mov -0x20(%%ebp),%%eax\n\t"
      "movzbl (%%eax),%%edx\n\t"
      "mov -0x18(%%ebp),%%eax\n\t"
      "mov %%dl,(%%eax)\n\t"
      "addq $0x1,-0x18(%%ebp)\n\t"
      "addq $0x1,-0x20(%%ebp)\n\t"
      "addq $0x1,-0xc(%%ebp)\n\t"
      "start:mov -0xc(%%ebp),%%eax\n\t"
      "cltq\n\t"
      "cmp %%eax,-0x28(%%ebp)\n\t"
      "ja loop\n\t"
      : [ pos ] "+g"(pos)
      : [ dest ] "m"(dest), [ src ] "m"(src), [ n ] "m"(n)
      : "%eax","%edx","cc","memory","%ebp" );

  return dest;
}

int asm_setjmp(asm_jmp_buf env)
{
  return setjmp(env);
}

void asm_longjmp(asm_jmp_buf env, int val)
{
  longjmp(env, val);
}
