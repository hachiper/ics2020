#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#define N 10000000

static bool is_prime[N];
static int primes[N];
int k=0;
int *sieve(int n)
{
  assert(n + 1 < N);
  
  memset(primes, 0, sizeof(primes));
  for (int i = 2; i * i <= n; i++)
  {
    if (is_prime[i])
    {
      primes[k++]=i;
      for (int j = i * i; j <= n; j += i)
    {
      is_prime[j] = 1;
      // k+=1;
    }
    }
  }
  // printf("%d\n",k);
  return primes;
}
