#include <stdbool.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#define N 10000000

static bool is_prime[N];
static int  primes[N];
int k=0;
int *sieve(int n) {
  is_prime[2]=true;
  assert(n + 1 < N);
  for (int i = 1; i <= n; i+=2)
    is_prime[i] = true;

  for (int i = 2; i * i<= n; i++) {
    for (int j = i *i; j <= n; j += i) {
      is_prime[j] = false;
      k+=1;
    }
  }
  printf("%d\n",k);

  int *p = primes;
  for (int i = 2; i <= n; i++)
    if (is_prime[i]) {
      *p++ = i;
    }
  *p = 0;
  return primes;
}
